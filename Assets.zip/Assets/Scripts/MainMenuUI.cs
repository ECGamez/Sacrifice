﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuUI : MonoBehaviour
{
    public void Yes ()
    {
        SceneManager.LoadScene("Fight01");
    }
    public void No ()
    {
        Application.Quit();
    }

    public void Controls ()
    {
        SceneManager.LoadScene("Controls");
    }
}
