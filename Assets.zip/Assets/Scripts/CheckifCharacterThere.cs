﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckifCharacterThere : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D col)
    {
        if(col.gameObject.tag == "Character")
        {
            StartCoroutine(Delay());
        }


        IEnumerator Delay ()
        {
            yield return new WaitForSeconds(2.5f);
            GameObject.Find("enemy").SendMessage("Punch");
        }
    }
}
