﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIFades : MonoBehaviour
{
    public Animator anim;

    bool calledfade = false;
    bool calledfade1 = false;

    public void Fade ()
    {
        if(!calledfade)
        {
            calledfade = true;
            anim.SetBool("fadein", true);
            anim.SetBool("fadeout", false);
            StartCoroutine(Fadeout());
        }
    }

    public void Fadeonce ()
    {
        if(!calledfade1)
        {
            anim.SetBool("fadein", true);
            anim.SetBool("fadeout", false);
            calledfade1 = true;
        }
    }

    IEnumerator Fadeout ()
    {
        yield return new WaitForSeconds(4f);
        anim.SetBool("fadein", false);
        anim.SetBool("fadeout", true);
        calledfade = false;
    }
}
