﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyHealth : MonoBehaviour
{
    float Curhealth { get; set; }
    float Maxhealth { get; set; }

    public Slider HPSlider;

    public Animator anim;

    private void Start()
    {
        Maxhealth = 100f;
        Curhealth = Maxhealth;
    }

    private void Update()
    {
        HPSlider.value = CalcHealth();
    }

    void TakeDamage(float damage)
    {
        Curhealth -= damage;
        HPSlider.value = CalcHealth();
        if (Curhealth <= 0)
        {
            Die();
        }
    }

    public void Punched ()
    {
        TakeDamage(27);
    }

    float CalcHealth ()
    {
        return Curhealth / Maxhealth;
    }

    void Die ()
    {
        Debug.Log("dead");
        anim.SetBool("IsDead", true);
        anim.SetBool("IsRun", false);
        anim.SetBool("IsIdle", false);
        anim.SetBool("IsPunch", false);
        FindObjectOfType<GameManager>().EndGame(true);
    }

    public void Punch ()
    {
        if(!anim.GetBool("IsDead"))
        {
            StartCoroutine(PunchCO());
        }
    }

    IEnumerator PunchCO ()
    {
        yield return new WaitForSeconds(1f);
        anim.SetBool("IsRun", false);
        anim.SetBool("IsIdle", false);
        anim.SetBool("IsPunch", true);
        yield return new WaitForSeconds(0.1f);
        anim.SetBool("IsRun", false);
        anim.SetBool("IsIdle", true);
        anim.SetBool("IsPunch", false);
    }

    public void Run ()
    {
        transform.Translate(-50 * Time.deltaTime, 0, 0);
        anim.SetBool("IsRun", true);
        anim.SetBool("IsIdle", false);
        anim.SetBool("IsPunch", false);
    }
}
