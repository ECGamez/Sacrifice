﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    bool GameHasEnded = false;

    public GameObject King;
    public GameObject No;
    public GameObject Yea;

    public GameObject EndUI;

    public GameObject StartWarriors;
    public GameObject TalkStart;

    public GameObject warrior1;
    public GameObject warrior2;
    public GameObject warrior3;
    public GameObject warrior4;
    public GameObject warrior5;

    public GameObject enemy;

    public GameObject HP;

    public bool started = false;

    public GameObject Wait;

    private void Start()
    {
        StartCoroutine(EndStart());
    }

    IEnumerator EndStart ()
    {
        yield return new WaitForSeconds(5f);
        GameObject.Find("Canvas").SendMessage("Fade");
        yield return new WaitForSeconds(1f);
        King.SetActive(false);
        TalkStart.SetActive(false);
        StartWarriors.SetActive(false);
        warrior1.SetActive(true);
        warrior2.SetActive(true);
        warrior3.SetActive(true);
        warrior4.SetActive(true);
        warrior5.SetActive(true);
        enemy.SetActive(true);
        HP.SetActive(true);
        FindObjectOfType<WhichMovedManager>().StartCharacters();
        started = true;
    }

    public void EndGame (bool won)
    {
        if(!GameHasEnded)
        {
            if(won)
            {
                StartCoroutine(Won());
                GameObject.Find("Canvas").SendMessage("Fade");
            }
            if(!won)
            {
                StartCoroutine(Lost());
            }
            GameHasEnded = true;
        }
    }

    IEnumerator Won()
    {
        yield return new WaitForSeconds(1f);
        King.SetActive(true);
        Yea.SetActive(true);
        if (FindObjectOfType<WhichMovedManager>().playersalive == 4)
        {
            Debug.Log("Yes");
            Wait.SetActive(true);
        }
        yield return new WaitForSeconds(7f);
        EndUI.SetActive(true);
    }
    IEnumerator Lost ()
    {
        yield return new WaitForSeconds(1f);
        GameObject.Find("Canvas").SendMessage("Fade");
        yield return new WaitForSeconds(1f);
        HP.SetActive(false);
        King.SetActive(true);
        No.SetActive(true);
        yield return new WaitForSeconds(5f);
        GameObject.Find("Canvas").SendMessage("Fadeonce");
        yield return new WaitForSeconds(2f);
        EndUI.SetActive(true);
    }
}
