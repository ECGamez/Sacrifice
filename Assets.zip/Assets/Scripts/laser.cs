﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class laser : MonoBehaviour
{
    public LineRenderer LR;
    private void Start()
    {
        Material whiteDiffuseMat = new Material(Shader.Find("Unlit/Texture"));
    }

    private void Update()
    {
        LR.SetPosition(0, transform.position);
        RaycastHit hit;
        if (Physics.Raycast(transform.position, transform.forward, out hit))
        {
            if (hit.collider)
            {
                LR.SetPosition(1, hit.point);
            }
        }
        else LR.SetPosition(1, transform.forward * 5f);
    }
}
