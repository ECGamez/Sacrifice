﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckClick : MonoBehaviour
{
    private void OnMouseDown()
    {
        this.transform.GetComponentInChildren<CharacterMovement>().Down();
    }
}
