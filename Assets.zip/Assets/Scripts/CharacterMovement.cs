﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour
{
    public Animator anim;

    bool Dead;

    Quaternion playerRot;

    Vector2 direction;

    Transform Pos;

    float dis;

    public Rigidbody2D rb;

    int playerNum;

    Vector2 move;

    bool Started = false;

    bool stoppedspeed = false;

    bool Noteffect = false;

    bool CantMove = false;

    bool punch = false;

    GameObject[] Players;

    private void Start()
    {
        Pos = GameObject.Find("enemy").transform;
        move = new Vector2(7, 0);
    }

    public void Update()
    {
        if (!Started)
            return;

        Dead = anim.GetBool("IsDead");

        dis = Vector3.Distance(Pos.position, this.transform.position);

        if(punch)
        {
            if (Input.GetKeyDown(KeyCode.P))
            {
                Debug.Log("Move");
                anim.SetBool("IsRun", false);
                anim.SetBool("IsIdle", false);
                anim.SetBool("IsWalk", false);
                anim.SetBool("Punch", true);
                punch = false;
                StartCoroutine(DamDelay());
            }
        }
    }

    IEnumerator DamDelay ()
    {
        yield return new WaitForSeconds(0.75f);
        GameObject.Find("enemy").SendMessage("Punched");
    }

    private void FixedUpdate()
    {
        if (!Started)
            return;

        if (anim.GetBool("IsRun"))
        {
            if (dis > 1f)
            {
                rb.MovePosition(rb.position + move * Time.fixedDeltaTime);
                stoppedspeed = false;
            }
            else if(dis < 1f)
            {
                if(!stoppedspeed)
                {
                    rb.velocity = Vector2.zero;
                    anim.SetBool("IsRun", false);
                    anim.SetBool("IsIdle", true);
                    anim.SetBool("IsWalk", false);
                    anim.SetBool("Punch", false);
                    stoppedspeed = true;
                    Players = GameObject.FindGameObjectsWithTag("Character");

                    GameObject.Find("enemy").SendMessage("Punch");
                    StartCoroutine(Death());

                    for (int i = 0; i < Players.Length; i++)
                    {
                        if (Players[i] == this.gameObject)
                        {
                            playerNum = i;
                            Debug.Log(playerNum);
                        }
                    }

                    FindObjectOfType<WhichMovedManager>().Which(playerNum);
                }
            }
        }
    }

    IEnumerator Death ()
    {
        yield return new WaitForSeconds(1.75f);
        anim.SetBool("IsDead", true);
        FindObjectOfType<WhichMovedManager>().Run();

        yield return new WaitForSeconds(3f);


        this.gameObject.SetActive(false);

        FindObjectOfType<WhichMovedManager>().add();
    }


    public void Down ()
    {
        if (!Started)
            return;

        if (!Dead)
        {
            if(!stoppedspeed)
            {
                if(!CantMove)
                {
                    anim.SetBool("IsRun", true);
                    anim.SetBool("IsIdle", false);
                    anim.SetBool("IsWalk", false);
                    anim.SetBool("Punch", false);
                    FindObjectOfType<WhichMovedManager>().NoRun();
                    Noteffect = true;
                    
                }
            }
        }

        Players = GameObject.FindGameObjectsWithTag("Character");
    }

    public void NotMove ()
    {
        if(!Noteffect)
        {
            CantMove = true;
        }
    }

    public void Move ()
    {
        CantMove = false;
    }

    public void Punch ()
    {
        if(!Dead)
        {
            punch = true;
        }
    }

    public void CanMove ()
    {
        Started = true;
    }
}
