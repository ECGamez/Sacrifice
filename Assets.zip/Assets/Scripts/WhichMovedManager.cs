﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WhichMovedManager : MonoBehaviour
{
    GameObject[] players;

    bool SendingMessage = false;

    public int playersalive;

    public GameObject Grave1;
    public GameObject Grave2;
    public GameObject Grave3;
    public GameObject Grave4;
    public GameObject Grave5;

    bool start = false;

    private void Update()
    {

        if (!start)
            return;
        players = GameObject.FindGameObjectsWithTag("Character");

        if(SendingMessage)
        {
            for (int i = 0; i < players.Length; i++)
            {
                players[i].SendMessage("NotMove");
            }
        }

        if (!SendingMessage)
        {
            for (int i = 0; i < players.Length; i++)
            {
                players[i].SendMessage("Move");
            }
        }

        if (playersalive == 1)
        {
            Grave1.SetActive(true);
            
        }
        if (playersalive == 2)
        {
            Grave2.SetActive(true);
        }
        if (playersalive == 3)
        {
            Grave3.SetActive(true);
        }
        if (playersalive == 4)
        {
            Grave4.SetActive(true);
        }
        if(start)
        {
            for (int i = 0; i < players.Length; i++)
            {
                players[i].SendMessage("CanMove");
            }
        }

        if (playersalive == 5)
        {
            GameObject.Find("enemy").SendMessage("Run");
            FindObjectOfType<GameManager>().EndGame(false);
            Grave5.SetActive(true);
        }
    }

    public void Which(int playerNumber)
    {
        if(playerNumber == 0)
        {
            players[0].SendMessage("Punch");
        }
        if (playerNumber == 1)
        {
            players[1].SendMessage("Punch");
        }
        if (playerNumber == 2)
        {
            players[2].SendMessage("Punch");
        }
        if (playerNumber == 3)
        {
            players[3].SendMessage("Punch");
        }
        if (playerNumber == 4)
        {
            players[4].SendMessage("Punch");
        }
    }

    public void NoRun ()
    {
        SendingMessage = true;
    }

    public void Run ()
    {
        SendingMessage = false;
    }

    public void add ()
    {
        playersalive++;
    }

    public void StartCharacters ()
    {
        start = true;
    }
}
